<?php
include "template/header_admin.php"
?>
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <style>
        .notification-container {
            height: calc(100vh - 2rem);
        }
        
        .scrollbar-custom::-webkit-scrollbar {
            width: 6px;
        }
        
        .scrollbar-custom::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        .scrollbar-custom::-webkit-scrollbar-thumb {
            background: #9333ea;
            border-radius: 3px;
        }
        
        .scrollbar-custom::-webkit-scrollbar-thumb:hover {
            background: #7c3aed;
        }

        .unread {
            background-color: #f3e8ff;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden notification-container">
            <!-- Header -->
            <div class="bg-purple-600 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-white text-xl font-semibold">Notifikasi</h1>
                    <div class="flex items-center space-x-4">
                        <button class="text-purple-200 hover:text-white text-sm">
                            Tandai semua sudah dibaca
                        </button>
                    </div>
                </div>
            </div>

            <!-- Navigation Tabs -->
            <div class="bg-white border-b border-gray-200">
                <div class="flex">
                    <button class="px-6 py-3 text-purple-600 border-b-2 border-purple-600 font-medium">
                        Semua (5)
                    </button>
                    <button class="px-6 py-3 text-gray-500 hover:text-purple-600">
                        Pesanan (3)
                    </button>
                    <button class="px-6 py-3 text-gray-500 hover:text-purple-600">
                        Penjemputan (2)
                    </button>
                </div>
            </div>

            <!-- Notification List -->
            <div class="overflow-y-auto scrollbar-custom" style="height: calc(100% - 8rem);">
                <!-- Unread Notification - Product Order -->
                <div class="border-b border-gray-100 hover:bg-purple-50 unread">
                    <div class="p-4">
                        <div class="flex items-start space-x-4">
                            <div class="bg-purple-100 rounded-full p-2">
                                <i class="fas fa-shopping-bag text-purple-600 text-lg"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between">
                                    <h3 class="font-semibold text-gray-800">Pesanan Baru #12345</h3>
                                    <span class="text-sm text-gray-500">2 menit yang lalu</span>
                                </div>
                                <p class="text-gray-600 mt-1">Amanda Salima - Rp 299.000</p>
                                <div class="mt-2">
                                    <span class="inline-block bg-purple-100 text-purple-600 text-xs px-2 py-1 rounded-full">
                                        Belum dibaca
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Unread Notification - Pickup Request -->
                <div class="border-b border-gray-100 hover:bg-purple-50 unread">
                    <div class="p-4">
                        <div class="flex items-start space-x-4">
                            <div class="bg-purple-100 rounded-full p-2">
                                <i class="fas fa-map-marker-alt text-purple-600 text-lg"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between">
                                    <h3 class="font-semibold text-gray-800">Permintaan Penjemputan #89012</h3>
                                    <span class="text-sm text-gray-500">5 menit yang lalu</span>
                                </div>
                                <p class="text-gray-600 mt-1">Lokasi: Jl. Sukajadi No. 123, Bandung</p>
                                <div class="mt-2">
                                    <span class="inline-block bg-purple-100 text-purple-600 text-xs px-2 py-1 rounded-full">
                                        Belum dibaca
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Read Notification - Product Order -->
                <div class="border-b border-gray-100 hover:bg-purple-50">
                    <div class="p-4">
                        <div class="flex items-start space-x-4">
                            <div class="bg-gray-100 rounded-full p-2">
                                <i class="fas fa-shopping-bag text-gray-600 text-lg"></i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between">
                                    <h3 class="font-semibold text-gray-800">Pesanan Baru #12346</h3>
                                    <span class="text-sm text-gray-500">10 menit yang lalu</span>
                                </div>
                                <p class="text-gray-600 mt-1">Widya Mustika - Rp 190.000</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Empty State (shown when no notifications) -->
                <div class="hidden text-center py-12">
                    <div class="bg-purple-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                        <i class="fas fa-bell text-purple-600 text-2xl"></i>
                    </div>
                    <h3 class="text-gray-800 font-semibold mb-1">Tidak Ada Notifikasi</h3>
                    <p class="text-gray-600">Anda akan melihat notifikasi untuk pesanan dan penjemputan di sini</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add click handlers for reading notifications
            const notifications = document.querySelectorAll('.unread');
            notifications.forEach(notification => {
                notification.addEventListener('click', function() {
                    this.classList.remove('unread');
                    const badge = this.querySelector('.bg-purple-100.text-purple-600');
                    if (badge) {
                        badge.remove();
                    }
                });
            });

            // Add handler for "Mark all as read"
            const markAllReadBtn = document.querySelector('button.text-purple-200');
            markAllReadBtn.addEventListener('click', function() {
                notifications.forEach(notification => {
                    notification.classList.remove('unread');
                    const badge = notification.querySelector('.bg-purple-100.text-purple-600');
                    if (badge) {
                        badge.remove();
                    }
                });
            });
        });
    </script>
</body>
<?php
include "template/footer_admin.php"
?>
</html>