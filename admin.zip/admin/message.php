<?php
include "template/header_admin.php"
?>
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <style>
        .chat-height {
            height: calc(100vh - 8rem);
        }

        .message-bubble {
            max-width: 75%;
            word-wrap: break-word;
        }

        .chat-messages {
            height: calc(100% - 6rem);
            overflow-y: auto;
        }

        .scrollbar-custom::-webkit-scrollbar {
            width: 6px;
        }

        .scrollbar-custom::-webkit-scrollbar-thumb {
            background: #9333ea;
            border-radius: 3px;
        }

        .typing-indicator span {
            animation: blink 1.4s infinite;
            animation-fill-mode: both;
        }

        .typing-indicator span:nth-child(2) {
            animation-delay: .2s;
        }

        .typing-indicator span:nth-child(3) {
            animation-delay: .4s;
        }

        @keyframes blink {
            0% { opacity: .1; }
            20% { opacity: 1; }
            100% { opacity: .1; }
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg overflow-hidden chat-height">
            <!-- Chat Header -->
            <div class="bg-purple-600 px-6 py-4 flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <img src="<?= HOST ?>/foto/Default_Picture.jpg" alt="Admin Avatar" class="w-10 h-10 rounded-full">
                    <div>
                        <h2 class="text-white text-lg font-semibold">Admin Chat</h2>
                        <span class="text-purple-200 text-sm">Sedang Aktif</span>
                    </div>
                </div>
                <div class="flex items-center space-x-3">
                    <button class="text-white hover:text-purple-200">
                        <i class="fas fa-search"></i>
                    </button>
                    <button class="text-white hover:text-purple-200">
                        <i class="fas fa-cog"></i>
                    </button>
                </div>
            </div>

            <!-- Chat Content -->
            <div class="flex h-full">
                <!-- Sidebar - Chat List -->
                <div class="w-1/4 border-r border-gray-200 bg-gray-50">
                    <div class="p-4">
                        <div class="relative">
                            <input type="text" placeholder="Cari percakapan..." 
                                   class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-purple-500">
                            <i class="fas fa-search absolute right-3 top-3 text-gray-400"></i>
                        </div>
                    </div>
                    <div class="overflow-y-auto scrollbar-custom" style="height: calc(100% - 80px);">
                        <!-- Chat List Items -->
                        <div class="cursor-pointer hover:bg-gray-100 p-4 border-b border-gray-200">
                            <div class="flex items-center space-x-3">
                                <img src="<?= HOST ?>/foto/manda.jpg" alt="User Avatar" class="w-10 h-10 rounded-full">
                                <div>
                                    <h3 class="text-sm font-semibold">Amanda Salima</h3>
                                    <p class="text-xs text-gray-600 truncate">Pesan terakhir dari pengguna...</p>
                                </div>
                                <span class="text-xs text-gray-500">12:30</span>
                            </div>
                        </div>
                        <!-- More chat items -->
                        <div class="cursor-pointer hover:bg-gray-100 p-4 border-b border-gray-200">
                            <div class="flex items-center space-x-3">
                                <img src="<?= HOST ?>/foto/widya.jpg" alt="User Avatar" class="w-10 h-10 rounded-full">
                                <div>
                                    <h3 class="text-sm font-semibold">Widya Mustika</h3>
                                    <p class="text-xs text-gray-600 truncate">Pesan terakhir dari pengguna...</p>
                                </div>
                                <span class="text-xs text-gray-500">Kemarin</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Main Chat Area -->
                <div class="flex-1 flex flex-col">
                    <!-- Chat Messages -->
                    <div class="chat-messages p-6 overflow-y-auto scrollbar-custom">
                        <!-- Example Received Message -->
                        <div class="flex items-start mb-4">
                            <img src="<?= HOST ?>/foto/manda.jpg" alt="User Avatar" class="w-8 h-8 rounded-full mr-3">
                            <div>
                                <div class="bg-gray-200 rounded-lg p-3 message-bubble">
                                    <p class="text-sm">Halo! Saya punya pertanyaan tentang pesanan saya.</p>
                                </div>
                                <span class="text-xs text-gray-500">12:30 PM</span>
                            </div>
                        </div>

                        <!-- Example Sent Message -->
                        <div class="flex items-start justify-end mb-4">
                            <div>
                                <div class="bg-purple-600 text-white rounded-lg p-3 message-bubble ml-auto">
                                    <p class="text-sm">Tentu, saya siap membantu. Apa detailnya?</p>
                                </div>
                                <span class="text-xs text-gray-500">12:31 PM</span>
                            </div>
                            <img src="<?= HOST ?>/foto/Default_Picture.jpg" alt="Admin Avatar" class="w-8 h-8 rounded-full ml-3">
                        </div>
                    </div>

                    <!-- Typing Indicator -->
                    <div class="px-6 py-2">
                        <div class="flex items-center space-x-2 typing-indicator">
                            <span class="bg-gray-500 rounded-full w-2 h-2"></span>
                            <span class="bg-gray-500 rounded-full w-2 h-2"></span>
                            <span class="bg-gray-500 rounded-full w-2 h-2"></span>
                        </div>
                    </div>

                    <!-- Input Area -->
                    <div class="border-t border-gray-200 bg-white px-4 py-3">
                        <div class="flex items-center space-x-3">
                            <button class="text-gray-500 hover:text-purple-600">
                                <i class="fas fa-paperclip"></i>
                            </button>
                            <textarea 
                                class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 resize-none"
                                rows="1" placeholder="Ketik pesan Anda..."></textarea>
                            <button class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const chatMessages = document.querySelector('.chat-messages');
            const messageInput = document.querySelector('textarea');
            const sendButton = document.querySelector('.fa-paper-plane').parentElement;

            // Auto-scroll to bottom
            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            // Send message function
            function sendMessage() {
                const message = messageInput.value.trim();
                if (message) {
                    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const messageHTML = `
                        <div class="flex items-start justify-end mb-4">
                            <div>
                                <div class="bg-purple-600 text-white rounded-lg p-3 message-bubble ml-auto">
                                    <p class="text-sm">${message}</p>
                                </div>
                                <span class="text-xs text-gray-500">${time}</span>
                            </div>
                            <img src="<?= HOST ?>/foto/Default_Picture.jpg" alt="Admin Avatar" class="w-8 h-8 rounded-full ml-3">
                        </div>
                    `;
                    chatMessages.insertAdjacentHTML('beforeend', messageHTML);
                    messageInput.value = '';
                    scrollToBottom();
                }
            }

            sendButton.addEventListener('click', sendMessage);

            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
        });
    </script>
</body>
<?php
include "template/footer_admin.php"
?>
</html>
