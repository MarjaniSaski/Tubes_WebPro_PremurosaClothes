
<?php
include "template/header_admin.php"
?>
<style>
    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh; /* Memastikan tinggi body minimal 100% layar */
    }

    main {
        flex: 1; /* Membuat konten utama fleksibel */
    }

    footer {
        background-color: #f8f9fa; /* Warna latar belakang footer */
        padding: 20px;
        text-align: left;
        border-top: 1px solid #ddd;
        clear: both;
    }
</style>
<body class="min-h-screen flex flex-col">
    <main class="flex-1 p-6">
        <!-- Main Content -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold"></h2>
            <div class="flex items-center">
                <input type="text" placeholder="Search" class="border rounded p-2 mr-4">
                <button class="bg-purple-500 text-white px-4 py-2 rounded" onclick="window.location.href='newproduct.html'">TAMBAH PRODUK</button>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-6">
            <!-- Product Card -->
            <div class="bg-white p-4 rounded shadow">
                <div class="bg-purple-200 h-32 mb-4 overflow-hidden rounded">
                    <img src="<?= HOST ?>/foto/40.png" alt="Foto Produk" class="w-full h-full object-cover">
                </div>
                <h3 class="text-lg font-bold">Jeans Coquette</h3>
                <p class="text-purple-500 font-bold">Rp 399.000</p>
                <p class="text-gray-500 mt-2">Trendy</p>
                <p class="text-gray-400 text-sm">Jeans bergaya modern yang cocok untuk segala suasana.</p>
            </div>
            <div class="bg-white p-4 rounded shadow">
                            <div class="bg-pink-200 h-32 mb-4 overflow-hidden rounded">
                                <img src="<?= HOST ?>/foto/5.png" alt="Foto Produk" class="w-full h-full object-cover">
                            </div>
                            <h3 class="text-lg font-bold">Blush Dress</h3>
                            <p class="text-purple-500 font-bold">Rp 250.000</p>
                            <p class="text-gray-500 mt-2">Feminin</p>
                            <p class="text-gray-400 text-sm">Gaun lembut berwarna pink yang membuat Anda tampil percaya diri dan cantik.</p>
                        </div>

                        <div class="bg-white p-4 rounded shadow">
                            <div class="bg-pink-200 h-32 mb-4 overflow-hidden rounded">
                                <img src="<?= HOST ?>/foto/41.png" alt="Foto Produk" class="w-full h-full object-cover">
                            </div>
                            <h3 class="text-lg font-bold">Sand Blouse</h3>
                            <p class="text-purple-500 font-bold">Rp 299.000</p>
                            <p class="text-gray-500 mt-2">Minimalis</p>
                            <p class="text-gray-400 text-sm">Blouse klasik berwarna beige yang cocok dipadukan dengan celana favorit Anda.</p>
                        </div>

                        <div class="bg-white p-4 rounded shadow">
                            <div class="bg-pink-200 h-32 mb-4 overflow-hidden rounded">
                                <img src="<?= HOST ?>/foto/42.png" alt="Foto Produk" class="w-full h-full object-cover">
                            </div>
                            <h3 class="text-lg font-bold">Sea Blouse</h3>
                            <p class="text-purple-500 font-bold">Rp 299.000</p>
                            <p class="text-gray-500 mt-2">Fresh</p>
                            <p class="text-gray-400 text-sm">Blouse biru yang menyegarkan, sempurna untuk acara santai atau ke kantor.</p>
                        </div>

                        <div class="bg-white p-4 rounded shadow">
                            <div class="bg-pink-200 h-32 mb-4 overflow-hidden rounded">
                                <img src="<?= HOST ?>/foto/43.png" alt="Foto Produk" class="w-full h-full object-cover">
                            </div>
                            <h3 class="text-lg font-bold">Sand T-Shirt</h3>
                            <p class="text-purple-500 font-bold">Rp 200.000</p>
                            <p class="text-gray-500 mt-2">Simple</p>
                            <p class="text-gray-400 text-sm">Kaos bernuansa netral yang cocok untuk layering atau digunakan sendiri.</p>
                        </div>

                        <div class="bg-white p-4 rounded shadow">
                            <div class="bg-pink-200 h-32 mb-4 overflow-hidden rounded">
                                <img src="<?= HOST ?>/foto/4.png" alt="Foto Produk" class="w-full h-full object-cover">
                            </div>
                            <h3 class="text-lg font-bold">Grid Dress</h3>
                            <p class="text-purple-500 font-bold">Rp 250.000</p>
                            <p class="text-gray-500 mt-2">Stylish</p>
                            <p class="text-gray-400 text-sm">Gaun dengan pola kotak yang trendi, cocok untuk tampilan berani dan unik.</p>
                        </div>
        </div>
    </main>
    <?php
        include "template/footer_admin.php"
    ?>
</body>
</html>
